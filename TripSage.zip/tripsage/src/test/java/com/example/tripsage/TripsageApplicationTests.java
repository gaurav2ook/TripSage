package com.example.tripsage;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TripsageApplicationTests {

	@Test
	void contextLoads() {
	}

}
