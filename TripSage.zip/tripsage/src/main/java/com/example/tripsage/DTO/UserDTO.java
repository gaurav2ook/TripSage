package com.example.tripsage.DTO;

public class UserDTO {

}
